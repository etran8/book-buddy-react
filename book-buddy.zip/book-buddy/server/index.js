const express = require('express');
const cors = require('cors');
const axios = require('axios');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const fs = require('fs');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.send('Server is running');
});

/// GENERATE TEXT
app.post('/generate-text', async (req, res) => {
  const { prompt } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 1000,
      }),
    });

    const data = await response.json();
    console.log('OpenAI status:', response.status);
    console.log('OpenAI raw response:', data);

    const text = data.choices?.[0]?.message?.content || 'No response';
    const outputDir = './output/text';

    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir);
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `${outputDir}/generated-${timestamp}.txt`;

    fs.writeFileSync(filename, text);
    console.log(`Saved output to ${filename}`);

    res.json({ result: text });
  } catch (error) {
    console.error('OpenAI error:', error);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

/// GENERATE IMAGES
app.post('/generate-image', async (req, res) => {
  const { prompt } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  try {
    const response = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: prompt,
        n: 1,
        size: '1024x1024',
      }),
    });

    const data = await response.json();
    const imageUrl = data.data?.[0]?.url;

    if (!imageUrl) {
      throw new Error('No image URL returned');
    }

    const outputDir = './output/images';
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir);
    }

    const imageResponse = await fetch(imageUrl);
    const buffer = await imageResponse.arrayBuffer();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filePath = `${outputDir}/generated-${timestamp}.png`;

    fs.writeFileSync(filePath, Buffer.from(buffer));
    console.log(`Saved image to ${filePath}`);   

    res.json({ imageUrl });
  } catch (error) {
    console.error('Image generation error:', error);
    res.status(500).json({ error: 'Something went wrong generating the image' });
  }
});


/// SEARCH AND TRENDS ROUTES
app.get('/api/search', async (req, res) => {
  const query = req.query.q;
  if (!query) {
    return res.status(400).json({ error: 'Missing search query' });
  }

  try {
    const response = await axios.get('https://serpapi.com/search', {
      params: {
        q: query,
        api_key: process.env.SERP_API_KEY,
        engine: 'google',
      },
    });

    res.json(response.data);
  } catch (error) {
    console.error('Error fetching from SerpAPI:', error.message);
    res.status(500).json({ error: 'Failed to fetch from SerpAPI' });
  }
});

app.get('/api/trends', async (req, res) => {
  const query = req.query.q;
  const dateRange = 'today 3-m'; // last ~3 months
  const geo = 'US';

  if (!query) {
    return res.status(400).json({ error: 'Missing search query' });
  }

  try {
    const response = await axios.get('https://serpapi.com/search', {
      params: {
        engine: 'google_trends',
        q: query,
        data_type: 'TIMESERIES',
        date: dateRange,
        geo: geo,
        api_key: process.env.SERP_API_KEY,
      },
    });

    // Use the correct path for timeline data
    const rawData = response.data.interest_over_time?.timeline_data || [];
    const timelineData = rawData.map(item => ({
      date: item.date,
      value: item.values?.[0]?.extracted_value || 0
    }));

    res.json({ timeline: timelineData });
  } catch (error) {
    console.error('Error fetching Google Trends from SerpAPI:', error.message);
    res.status(500).json({ error: 'Failed to fetch Google Trends' });
  }
});


app.listen(3001, () => {
  console.log('Server is running on http://localhost:3001');
});
