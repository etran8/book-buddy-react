import { useState } from 'react';

function PromptForm() {
  const [prompt, setPrompt] = useState('');
  const [mode, setMode] = useState('text');
  const [loading, setLoading] = useState(false);
  const [generatedText, setGeneratedText] = useState('');
  const [generatedImage, setGeneratedImage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!prompt.trim()) return;

    setLoading(true);
    setError('');
    setGeneratedText('');
    setGeneratedImage('');

    try {
      if (mode === 'text') {
        const response = await fetch('http://localhost:3001/generate-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt }),
        });

        const data = await response.json();
        
        if (response.ok) {
          setGeneratedText(data.result);
          console.log('Generated text:', data.result);
        } else {
          setError(data.error || 'Failed to generate text');
        }
      } else if (mode === 'image') {
        const response = await fetch('http://localhost:3001/generate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt }),
        });

        const data = await response.json();
        
        if (response.ok) {
          setGeneratedImage(data.imageUrl);
          console.log('Generated image URL:', data.imageUrl);
        } else {
          setError(data.error || 'Failed to generate image');
        }
      }
    } catch (error) {
      console.error('Error generating content:', error);
      setError('Network error. Please make sure the server is running.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="form-container">
      {!generatedText && !generatedImage && !loading && (
        <div className="intro-section-small">
          <p>
            Enter a prompt to generate AI-powered text or images.
            Choose your output type and let AI create for you.
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <h2>Enter your prompt</h2>

        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe what you want to generate..."
          disabled={loading}
        />

        <div className="radio-group">
          <label>
            <input
              type="radio"
              name="mode"
              value="text"
              checked={mode === 'text'}
              onChange={() => setMode('text')}
              disabled={loading}
            />
            Text
          </label>
          <label>
            <input
              type="radio"
              name="mode"
              value="image"
              checked={mode === 'image'}
              onChange={() => setMode('image')}
              disabled={loading}
            />
            Image
          </label>
        </div>

        <button type="submit" disabled={loading}>
          {loading ? 'Generating...' : 'Generate'}
        </button>
      </form>

      {/* Output Display Area */}
      {error && (
        <div className="output-container error">
          <h3>❌ Error</h3>
          <p>{error}</p>
        </div>
      )}

      {loading && (
        <div className="output-container loading">
          <div className="spinner"></div>
          <p>Generating your {mode}...</p>
        </div>
      )}

      {generatedText && !loading && (
        <div className="output-container">
          <h3>✨ Generated Text</h3>
          <div className="text-output">
            {generatedText}
          </div>
        </div>
      )}

      {generatedImage && !loading && (
        <div className="output-container">
          <h3>✨ Generated Image</h3>
          <div className="image-output">
            <img src={generatedImage} alt="Generated content" />
          </div>
        </div>
      )}
    </div>
  );
}

export default PromptForm;
