function HomePage({ onNavigate }) {
  return (
    <div className="home-page">
      <h1>✨ BookBuddy Platform</h1>
      <p className="subtitle">Choose a tool to get started</p>
      
      <div className="button-grid">
        <button 
          className="nav-button" 
          onClick={() => onNavigate('ai-generator')}
        >
          <span className="button-icon">🤖</span>
          <span className="button-title">AI Content Generator</span>
          <span className="button-description">Generate text and images with AI</span>
        </button>

        <button 
          className="nav-button" 
          onClick={() => onNavigate('web-scraper')}
        >
          <span className="button-icon">🔍</span>
          <span className="button-title">Web Scraper</span>
          <span className="button-description">Search and analyze web trends</span>
        </button>

        <button 
          className="nav-button" 
          onClick={() => onNavigate('business-finance')}
        >
          <span className="button-icon">💼</span>
          <span className="button-title">Business Finance Tracker</span>
          <span className="button-description">Track expenses, revenue, and financial metrics</span>
        </button>
      </div>
    </div>
  );
}

export default HomePage;
