import { useState } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import SearchBar from './SearchBar';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function WebScraper() {
  const [results, setResults] = useState([]);
  const [timeline, setTimeline] = useState([]);
  const [showGraph, setShowGraph] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (query) => {
    setHasSearched(true);
    setLoading(true);
    try {
      // Fetch normal search results
      const searchResponse = await fetch(`http://localhost:3001/api/search?q=${encodeURIComponent(query)}`);
      const searchData = await searchResponse.json();
      const searchResults = searchData.organic_results?.map(result => ({
        title: result.title,
        link: result.link,
        snippet: result.snippet
      })) || [];
      setResults(searchResults);

      // Fetch trends data
      const trendsResponse = await fetch(`http://localhost:3001/api/trends?q=${encodeURIComponent(query)}`);
      const trendsData = await trendsResponse.json();
      setTimeline(trendsData.timeline || []);

      // Show the graph by default if there is data
      if (trendsData.timeline && trendsData.timeline.length) {
        setShowGraph(true);
      }

    } catch (err) {
      console.error('Error fetching data:', err);
      setResults([]);
      setTimeline([]);
    } finally {
      setLoading(false);
    }
  };

  const chartData = {
    labels: timeline.map(item => item.date),
    datasets: [
      {
        label: 'Search Interest',
        data: timeline.map(item => item.value),
        borderColor: 'rgba(102, 126, 234, 1)',
        backgroundColor: 'rgba(102, 126, 234, 0.2)',
        fill: true,
        tension: 0.4,
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: true,
        position: 'top',
      },
      title: {
        display: true,
        text: 'Search Interest Over Time',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      }
    }
  };

  return (
    <div className="web-scraper-container">
      {!hasSearched && (
        <div className="intro-section-small">
          <p>
            Type in a keyword to see live search results and trends data.
            Switch to graph view to explore interest over time.
          </p>
        </div>
      )}

      <SearchBar onSearch={handleSearch} />

      {hasSearched && (
        <div className="toggle-button-container">
          <button className="toggle-view-button" onClick={() => setShowGraph(!showGraph)}>
            {showGraph ? '📊 Show Results' : '📈 Show Graph'}
          </button>
        </div>
      )}

      {loading && (
        <div className="output-container loading">
          <div className="spinner"></div>
          <p>Searching...</p>
        </div>
      )}

      {showGraph && timeline.length > 0 && !loading ? (
        <div className="chart-wrapper">
          <Line data={chartData} options={chartOptions} />
        </div>
      ) : !loading && results.length > 0 ? (
        <div className="search-results">
          {results.map((item, index) => (
            <div key={index} className="result-item">
              <a href={item.link} target="_blank" rel="noopener noreferrer">
                {item.title}
              </a>
              <p>{item.snippet}</p>
            </div>
          ))}
        </div>
      ) : !loading && hasSearched ? (
        <div className="output-container">
          <p>No results found.</p>
        </div>
      ) : null}
    </div>
  );
}
