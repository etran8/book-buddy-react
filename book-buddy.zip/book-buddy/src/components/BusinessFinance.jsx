import { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

function BusinessFinance() {
  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem("transactions");
    return saved ? JSON.parse(saved) : [];
  });
  
  const [showLog, setShowLog] = useState(false);
  const [showChart, setShowChart] = useState(false);

  useEffect(() => {
    localStorage.setItem("transactions", JSON.stringify(transactions));
  }, [transactions]);

  const handleInputFinances = () => {
    const typeRaw = window.prompt('Type "revenue" or "expense":');
    if (typeRaw === null) return;

    const type = typeRaw.trim().toLowerCase();
    if (type !== "revenue" && type !== "expense") {
      alert('Please enter exactly "revenue" or "expense".');
      return;
    }

    const amtRaw = window.prompt(`Enter ${type} amount (e.g. 123.45):`);
    if (amtRaw === null) return;

    const amount = parseFloat(amtRaw);
    if (!Number.isFinite(amount) || amount <= 0) {
      alert("Please enter a positive number.");
      return;
    }

    const tx = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      type,
      amount,
      timestamp: new Date().toISOString(),
    };

    setTransactions((prev) => [...prev, tx]);
  };

  const handleDeleteFinances = () => {
    setShowLog((prev) => !prev);
    setShowChart(false);
  };

  const handlePlotFinances = () => {
    setShowChart((prev) => !prev);
    setShowLog(false);
  };

  const deleteTransaction = (id) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const totalRevenue = transactions
    .filter((t) => t.type === "revenue")
    .reduce((acc, t) => acc + t.amount, 0);

  const totalExpenses = transactions
    .filter((t) => t.type === "expense")
    .reduce((acc, t) => acc + t.amount, 0);

  const total = totalRevenue - totalExpenses;

  const format = (n) => n.toFixed(2);

  // Calculate monthly values (last 30 days)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const monthlyExpenses = transactions
    .filter((t) => t.type === "expense" && new Date(t.timestamp) > thirtyDaysAgo)
    .reduce((acc, t) => acc + t.amount, 0);

  const monthlyRevenue = transactions
    .filter((t) => t.type === "revenue" && new Date(t.timestamp) > thirtyDaysAgo)
    .reduce((acc, t) => acc + t.amount, 0);

  // Prepare chart data
  const sortedTransactions = [...transactions].sort(
    (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
  );

  const chartLabels = sortedTransactions.map((t) =>
    new Date(t.timestamp).toLocaleDateString()
  );

  let runningTotal = 0;
  const chartData = sortedTransactions.map((t) => {
    if (t.type === "revenue") {
      runningTotal += t.amount;
    } else {
      runningTotal -= t.amount;
    }
    return runningTotal;
  });

  const chartConfig = {
    labels: chartLabels,
    datasets: [
      {
        label: 'Balance Over Time',
        data: chartData,
        borderColor: '#667eea',
        backgroundColor: 'rgba(102, 126, 234, 0.1)',
        tension: 0.3,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Financial Balance Timeline',
      },
    },
    scales: {
      y: {
        ticks: {
          callback: (value) => '$' + value.toFixed(2),
        },
      },
    },
  };

  return (
    <div className="finance-container">
      <div className="intro-section-small">
        <p>
          Track your business finances with detailed expense and revenue management.
          Input data, visualize trends, and monitor your financial health.
        </p>
      </div>

      <div className="finance-buttons">
        <button className="finance-action-btn" onClick={handleInputFinances}>
          Input Finances
        </button>
        <button className="finance-action-btn" onClick={handleDeleteFinances}>
          {showLog ? 'Hide Transactions' : 'Delete Finances'}
        </button>
        <button className="finance-action-btn" onClick={handlePlotFinances}>
          {showChart ? 'Hide Chart' : 'Plot Finances'}
        </button>
      </div>

      <div className="finance-stats">
        <div className="stats-row">
          <div className="stat-item">
            <span className="stat-label">Total Expenses:</span>
            <span className="stat-value">${format(totalExpenses)}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Monthly Expenses:</span>
            <span className="stat-value">${format(monthlyExpenses)}</span>
          </div>
        </div>

        <div className="stats-row">
          <div className="stat-item">
            <span className="stat-label">Total Revenue:</span>
            <span className="stat-value">${format(totalRevenue)}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Monthly Revenue:</span>
            <span className="stat-value">${format(monthlyRevenue)}</span>
          </div>
        </div>

        <div className="total-row">
          <span className="total-label">Total:</span>
          <span className="total-value">${format(total)}</span>
        </div>
      </div>

      {showLog && (
        <div className="transaction-log">
          <h3>Transaction Log</h3>
          {transactions.length === 0 ? (
            <p style={{ textAlign: 'center', color: '#666' }}>No transactions yet.</p>
          ) : (
            <ul className="transaction-list">
              {[...transactions]
                .reverse()
                .map((t) => (
                  <li key={t.id} className="transaction-item">
                    <span className="transaction-date">
                      {new Date(t.timestamp).toLocaleString()}
                    </span>
                    <span className={`transaction-amount ${t.type}`}>
                      {t.type === "revenue" ? "+" : "-"}${format(t.amount)}
                    </span>
                    <button
                      className="delete-btn"
                      onClick={() => deleteTransaction(t.id)}
                    >
                      Delete
                    </button>
                  </li>
                ))}
            </ul>
          )}
        </div>
      )}

      {showChart && transactions.length > 0 && (
        <div className="chart-wrapper">
          <Line data={chartConfig} options={chartOptions} />
        </div>
      )}

      {showChart && transactions.length === 0 && (
        <div className="output-container">
          <p style={{ textAlign: 'center', color: '#666' }}>
            No transactions to plot. Add some data first!
          </p>
        </div>
      )}
    </div>
  );
}

export default BusinessFinance;
