import { useState } from 'react';
import HomePage from './components/HomePage';
import PromptForm from './components/PromptForm';
import WebScraper from './components/WebScraper';
import BusinessFinance from './components/BusinessFinance';
import './App.css';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const handleNavigate = (page) => {
    setCurrentPage(page);
  };

  const handleBackHome = () => {
    setCurrentPage('home');
  };

  return (
    <div>
      {currentPage === 'home' && (
        <HomePage onNavigate={handleNavigate} />
      )}

      {currentPage === 'ai-generator' && (
        <div>
          <button className="back-button" onClick={handleBackHome}>
            ← Back to Home
          </button>
          <h1>✨ AI Content Generator</h1>
          <PromptForm />
        </div>
      )}

      {currentPage === 'web-scraper' && (
        <div>
          <button className="back-button" onClick={handleBackHome}>
            ← Back to Home
          </button>
          <h1>🔍 SearchTrends Analytics</h1>
          <WebScraper />
        </div>
      )}

      {currentPage === 'business-finance' && (
        <div>
          <button className="back-button" onClick={handleBackHome}>
            ← Back to Home
          </button>
          <h1>💼 Business Finance Tracker</h1>
          <BusinessFinance />
        </div>
      )}
    </div>
  );
}

export default App;
